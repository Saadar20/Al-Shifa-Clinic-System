import { createClient } from 'https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2/+esm';

const SUPABASE_URL = "https://qjnposuqtkqqlpdjaswx.supabase.co";
// مفتاحك الصحيح والنظيف تماماً بدون أي تعديلات
const SUPABASE_KEY = "sb_publishable_F4xMzIit0CYKfmOipM5UHg_IiRz7p8E"; 

const db = createClient(SUPABASE_URL, SUPABASE_KEY);

window.loadDashboard = async function() {
  const rowsContainer = document.getElementById('rowsContainer');
  const totalCountLabel = document.getElementById('totalCount');
  
  if (!rowsContainer) return;
  
  rowsContainer.innerHTML = '<tr><td colspan="6" style="text-align:center; color:#aaa;">جاري سحب الحجوزات الحية...</td></tr>';
  
  const { data, error } = await db
    .from('appointments')
    .select('*');

  if (error) {
    rowsContainer.innerHTML = `<tr><td colspan="6" style="color:#ff4d4d; text-align:center;">حدث خطأ أثناء القراءة: ${error.message}</td></tr>`;
    return;
  }

  rowsContainer.innerHTML = '';
  
  if (totalCountLabel) {
    totalCountLabel.innerText = data ? data.length : 0;
  }

  if (!data || data.length === 0) {
    rowsContainer.innerHTML = '<tr><td colspan="6" style="text-align:center; color:#aaa;">لا توجد مواعيد مسجلة حالياً بالعيادة.</td></tr>';
    return;
  }

  data.forEach(item => {
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td><strong>${item.patient_name || 'غير مسجل'}</strong></td>
      <td><a href="tel:${item.phone || ''}" style="color: #deff9a; text-decoration: none;">${item.phone || 'بدون هاتف'}</a></td>
      <td>${item.appointment_date || 'غير محدد'}</td>
      <td><span class="time-tag">${item.appointment_time || '--:--'}</span></td>
      <td>${item.treatment_type || 'فحص عام'}</td>
      <td>
        <button class="delete-btn" onclick="deleteAppointment('${item.id}')">
          حذف
        </button>
      </td>
    `;
    rowsContainer.appendChild(tr);
  });
}

window.deleteAppointment = async function(id) {
  if (confirm('هل ترغب في إتمام هذا الموعد وإزالته من جدول الطبيب؟')) {
    const { error } = await db.from('appointments').delete().eq('id', id);
    if (!error) {
      window.loadDashboard(); 
    } else {
      alert("لم نتمكن من الحذف: " + error.message);
    }
  }
}

window.loadDashboard();