const SUPABASE_URL = "https://qjnposuqtkqqlpdjaswx.supabase.co";
const SUPABASE_KEY = "sb_publishable_F4xMzIit0CYKfmOipM5UHg_IiRz7p8E";

// الربط المباشر المضمون للمتصفح
const db = supabase.createClient(SUPABASE_URL, SUPABASE_KEY);

const btnBook = document.getElementById("btnBook");

if (btnBook) {
  btnBook.addEventListener("click", async (e) => {
    e.preventDefault();

    const patientName = document.getElementById("patientName").value;
    const patientPhone = document.getElementById("patientPhone").value;
    const appointmentDate = document.getElementById("appointmentDate").value;
    const appointmentTime = document.getElementById("appointmentTime").value;
    const treatmentType = document.getElementById("treatmentType").value;
    const bookingMessage = document.getElementById("bookingMessage");

    if (!patientName || !patientPhone || !appointmentDate) {
      alert("الرجاء تعبئة الاسم ورقم الهاتف والتاريخ أولاً!");
      return;
    }

    if (bookingMessage) bookingMessage.innerText = "جاري إرسال الحجز...";

    // إرسال البيانات مباشرة إلى السيرفر
    const { data, error } = await db.from("appointments").insert([
      {
        patient_name: patientName,
        phone: patientPhone,
        appointment_date: appointmentDate,
        appointment_time: appointmentTime,
        treatment_type: treatmentType
      }
    ]);
    if (!error) {
      if (bookingMessage) {
        bookingMessage.style.color = "#2a9d8f"; 
        bookingMessage.innerHTML = "🎉 <strong>تم تسجيل حجزك بنجاح في عيادة الشفاء!</strong>";
      }
      document.getElementById('patientName').value = "";
      document.getElementById('patientPhone').value = "";
      document.getElementById('appointmentDate').value = "";
    } else {
      if (error.message.includes('unique_appointment') || error.code === '23505') {
        if (bookingMessage) {
          bookingMessage.style.color = "#e63946"; 
          bookingMessage.innerHTML = "⚠️ <strong>عذراً، هذا الموعد محجوز مسبقاً!</strong> يرجى اختيار وقت آخر.";
        }
      } else {
        if (bookingMessage) {
          bookingMessage.style.color = "#e63946";
          bookingMessage.innerHTML = "❌ حدث خطأ أثناء الحجز: " + error.message;
        }
      }
    }
  });
}